clear all, clc, close all;

load 0037-nove.mat;

figure
plot(data(:,1),data(:,3));
y=data(:,3)-0.04077;
t=data(:,1);
vystup = timeseries(y,t);legend ('posX');grid on; %posX vozika
xlabel('cas(s)')
ylabel('poloha(m)')
title('Poloha vozika')

figure
plot(data(:,1),data(:,4)); 
y_fi=data(:,4)-0.001533980787886;
t_fi=data(:,1);
fi = timeseries(y_fi,t_fi);legend ('PhiX');grid on; % PhiX- vychylkaX
xlabel('cas(s)')
ylabel('PhiX(rad)')
title('Poloha bremena')

figure
plot(data(:,1),data(:,5)); 
y_in=data(:,5);
t_in=data(:,1);
simin = timeseries(y_in,t_in);legend ('inputX');grid on; % input v X
xlabel('cas(s)')
ylabel('omega(rad/s)')
title('Vstupne data')


%% Identifikacia
% pre vozik
K=0.17; T=0.02;  %0.17 0.005
%K=0.548; T=0.106;  dead=0.141; %0.139
%K=0.548; T=0.106;  dead=0.141;

% pre rameno
Kv=-0.1107;
omega=3.4799;
b=0.0078;%0.012
L=0.8;
sim('model.slx');
y_x_rameno=ans.vystupX_rameno;

% pre rameno FI
% Kv=-0.14;
% omega=4.18;
% b=0.008;
sim('model.slx');
y_fi_rameno=ans.vzstupFi_rameno;

sim('model.slx');
tsim=ans.t;
simt=ans.t1;
y_x_vozik=ans.vystupX_vozik;


yin=ans.yin_sim;
%% Vzkreslenie
figure
plot(tsim,y_x_vozik)
hold on
plot(t,y)
xlabel('cas(s)')
ylabel('poloha(m)')
title('Porovnanie dat')
legend('model','real')

figure
plot(tsim,y_x_rameno)
hold on
plot(t,y_fi)
xlabel('cas(s)')
ylabel('PhiX(rad)')
title('Poloha bremena')
legend('model','real')

% figure
% plot(tsim,y_fi_rameno)
% plot(t,y_fi)
% title('Pozadovane data/ namerane')

figure
axis([0 60 0 0.2])
% plot(tsim,y_x_vozik)
hold on
% plot(t,y)
plot(t_in,y_in)
grid on;
plot([54.2,54.2],[0 0.2],'--')
xlabel('cas(s)')
ylabel('omega(rad/s)')
title('Porovnanie dat')
plot(tsim,y_x_vozik,'-')
plot(t,y,'-')
yyaxis right

ylabel('poloha(m)')
axis([0 60 0 0.2])
legend('vstup', 'dead zone', 'model vozika', 'real')

%% Regulacia

%Filter vstupu
A=21;
B=9.18;
jerk=5;
pom=B*B-4*A; % musi platit B^2-4A > 0

% Regulator 2 v pripade Regulatora 3 je +- a nie ++
Tvz=0.01;
Nel=10000;
Kp=100;
Ki=55;
Kp2=10;
Kd2=0.3;
sim('regulacia2.slx');

figure
x=ans.x;
y=ans.y;
xt=[0.1 0.4 0.4 0.1];
yt=[0.1 0.1 0.4 0.4];
plot(x,y,'-')
hold on
plot(xt,yt,'--')
xlabel('x(m)')
ylabel('y(m)')
title('Trajektoria ABCD')
legend('real','chcene')

text(0.07,0.1,' A')
text(0.43,0.1,' B')
text(0.43,0.4,' C')
text(0.07,0.4,' D')

figure
x=ans.x;
xc=ans.xc;
t1=ans.t1;
plot(t1,x)
hold on
plot(t1,xc)
xlabel('cas(s)')
ylabel('Poloha x(m)')
title('Casovy priebeh ABCD')
legend('real','chcene')


% Regulator 1

Tvz=0.01;
Nel=10000;
Kp=360.8781,  Ki=60.2976,  Kd=69.8555,   Kp2=239.9749,  Kd2=70.8221
sim('regulacia1.slx');

figure
x=ans.x;
y=ans.y;
xt=[0.1 0.4 0.4 0.1];
yt=[0.1 0.1 0.4 0.4];
plot(x,y,'-')
hold on
plot(xt,yt,'--')
xlabel('x(m)')
ylabel('y(m)')
title('Trajektoria ABCD')
legend('real','chcene')

text(0.07,0.1,' A')
text(0.43,0.1,' B')
text(0.43,0.4,' C')
text(0.07,0.4,' D')

figure
x=ans.x;
xc=ans.xc;
t1=ans.t1;
plot(t1,x)
hold on
plot(t1,xc)
xlabel('cas(s)')
ylabel('Poloha x(m)')
title('Casovy priebeh ABCD')
legend('real','chcene')
